package viewtraversal;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Stack;

import soot.jimple.infoflow.android.axml.AXmlAttribute;
import soot.jimple.infoflow.android.axml.AXmlNode;


public class SensitivePoint {

	
	private List<Stack<String>> methodsToSensi = new ArrayList<Stack<String>>();
	
	private Map<String, String> startActivityPoint = new HashMap<String, String>();
	private Map<String, Set<String>> callbackMethods = new HashMap<String, Set<String>>();
	Set<String> otherActivities = new HashSet<String>();
	
	private boolean haveNextLevel = true;
	private Map<String, Set<SensitivePoint>> events = new HashMap<String, Set<SensitivePoint>>();
	

	
	public void setEvents(){
		List<String> newset = new ArrayList<String>();
		Iterator<Stack<String>> stacks =  methodsToSensi.iterator();
		while (stacks.hasNext()) {
			Stack<String> stack = stacks.next();
			while (!stack.empty()) {
				newset.add(stack.pop());
			}
		}
	}
	
	
	

	
	
	public Map<String, Set<SensitivePoint>> getEvents() {
		return events;
	}

	public void setEvents(Map<String, Set<SensitivePoint>> events) {
		this.events = events;
	}

	public boolean isHaveNextLevel() {
		return haveNextLevel;
	}

	public void setHaveNextLevel(boolean haveNextLevel) {
		this.haveNextLevel = haveNextLevel;
	}
	
	public List<Stack<String>> getMethodsToSensi() {
		return methodsToSensi;
	}
	public void setMethodsToSensi(List<Stack<String>> methodsToSensi) {
		this.methodsToSensi = methodsToSensi;
	}
	public Map<String, String> getStartActivityPoint() {
		return startActivityPoint;
	}
	public void setStartActivityPoint(Map<String, String> startActivityPoint) {
		this.startActivityPoint = startActivityPoint;
	}
	public Map<String, Set<String>> getCallbackMethods() {
		return callbackMethods;
	}
	public void setCallbackMethods(Map<String, Set<String>> callbackMethods) {
		this.callbackMethods = callbackMethods;
	}
	
	
	public void printStartActivityPoint(){
		for(Map.Entry<String, String> point: startActivityPoint.entrySet()){
			System.out.println(point.getKey() + " -------> " + point.getValue());
		}
	}
	
	public void printMethodsToSensi(){
		Iterator<Stack<String>> stacks =  methodsToSensi.iterator();
		while(stacks.hasNext()){
			Stack<String> stack = stacks.next();
			List<String> newset = new ArrayList<String>();
			
			while(!stack.empty()){
				newset.add(stack.pop());
				
			}
			for(String ac:newset){
				System.out.print( " .......> " + ac);
			}
		
			System.out.println();
		}
	}
	public Set<String> getOtherActivities() {
		return otherActivities;
	}
	
	public void setOtherActivities(String apkFileLocation) {
		Set<String> sensiceActivities = new HashSet<String>();
		Set<String> startActivity = startActivityPoint.keySet();
		for (Stack<String> stack : methodsToSensi) {

			String name = stack.peek();
			String[] strs = name.split("\\.");
			name = strs[(strs.length) - 1];
			sensiceActivities.add("." + name);
			// System.out.println(name);
		}
		for (String ac : startActivity) {
			int index = ac.indexOf("$");
			String name = ac.substring(0, index);
			String[] strs = name.split("\\.");
			name = strs[strs.length - 1];
			sensiceActivities.add("." + name);
			// System.out.println(name);
		}

		Set<String> otherActivities = new HashSet<String>();

		ClickTestEnchance clickTest = new ClickTestEnchance(apkFileLocation);
		ArrayList<AXmlNode> activityList = clickTest.getActivityList();
		for (AXmlNode node : activityList) {
			Map<String, AXmlAttribute<?>> attr = node.getAttributes();
			Collection<AXmlAttribute<?>> values = attr.values();
			for (AXmlAttribute<?> value : values) {
				String name = (String) value.getValue();
				otherActivities.add(name);
				// System.out.println(name);
				break;
			}

		}
		Set<String> otherActivities01 = new HashSet<String>();
		for (String other : otherActivities) {
			otherActivities01.add(other);
		}

		for (String sensi : sensiceActivities)
			for (String other : otherActivities01) {
				if (other.equals(sensi))
					otherActivities.remove(other);
			}
		System.out.println();
		for (String other : otherActivities) {
			System.out.println(other);
		}
		
		this.otherActivities = otherActivities;
	}
	
}
