package viewtraversal;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;


import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRichTextString;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.dom4j.Attribute;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

public class XmlToExcel {

	 public List<HashMap<String,String>> elementList = new ArrayList<HashMap<String, String>>();	
     
	// ������document
	public Element getRootElement(String filePath) {
		SAXReader saxread = new SAXReader();
		Document document = null;

		InputStream inputStream;
		try {
			File xmlFile = new File(filePath);
			inputStream = new FileInputStream(xmlFile);
			document = saxread.read(inputStream);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (DocumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		Element elem = document.getRootElement();
		return elem;
	}


	public void getNodes(Element elem) {
		List<Attribute> listAttr = elem.attributes();
		// List<HashMap<String,String>> elementList = new
		// ArrayList<HashMap<String, String>>();

		HashMap<String, String> attrOfNode = new HashMap<String, String>();
		for (Attribute attr : listAttr) {
			String name = attr.getName();
			String value = attr.getValue();
			attrOfNode.put(name, value);
		}
		elementList.add(attrOfNode);

		List<Element> listElement = elem.elements();
		for (Element e : listElement) {
			this.getNodes(e);
		}
	}
	
	public String[][] setViewInfo(List<HashMap<String,String>> elementList){
	
		elementList.remove(0);
		int num = elementList.size();
		String context[][] = new String[num][6];
		int i = 0;
		for(HashMap<String,String> node:elementList){  //node
			Iterator iterator = node.entrySet().iterator();
			
			while(iterator.hasNext()){   //attribute
				Map.Entry entry = (Map.Entry)iterator.next();
				String name = (String) entry.getKey();
				String value = (String) entry.getValue();
				if(name == "clickable" || name == "resource-id" 
						|| name == "bounds" || name == "long-clickable" || name == "text" || name == "scrollable")
				switch(name){
					case "clickable": 
						context[i][2] = value;break;
					case "resource-id":
						context[i][0] = value;
						break;
					case "bounds" :
						context[i][5] = value;break;
					case "long-clickable":
						context[i][4] = value;break;
					case "text":
						context[i][1] = value;break;
					case "scrollable":
						context[i][3] = value;break;
					default:
						break;
				}
				else{
					continue;
				}
			}
			
			i++;
		}
		return context;
	}
	
	public void toExcel(String context[][], String outputFilePath){
		String[] headers = {"uiId", "uiText", "clickable", "scrollable", "longclickable","bounds","clicked"};
		
		HSSFWorkbook wb = new HSSFWorkbook(); 
		HSSFSheet sheet = wb.createSheet("ViewInfo");
		FileOutputStream fileOut = null;
		try {
			fileOut = new FileOutputStream(outputFilePath);
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		//���ɱ�����
		HSSFRow row = sheet.createRow((short)0);
		for (short i = 0; i < headers.length; i++) {
		    HSSFCell cell = row.createCell(i);
		    HSSFRichTextString text = new HSSFRichTextString(headers[i]);
		    cell.setCellValue(text);
		}
		
		//������
        for(int i = 0; i< context.length; i++){
        	/*if(context[i][0].isEmpty()){
    			continue;
    		}*/
        	HSSFRow datarow = sheet.createRow(i+1);
        	for(int j = 0; j< 7; j++){
        		HSSFCell cell = datarow.createCell(j);
        		if(j == 6){
        			HSSFRichTextString text = new HSSFRichTextString("false");
        			cell.setCellValue(text);
        		}
        		else{
        		HSSFRichTextString text = new HSSFRichTextString(context[i][j]);
    		    cell.setCellValue(text);
        		}
        		
        	}
        }
	
		try {
			wb.write(fileOut);
			fileOut.close();
			wb.close();
			System.out.println("Excel �ɹ�");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	   
	}
	
	public void setExcelCellContext(int column, int row, String context,String outPutFilePath){
		HSSFWorkbook workbook;
		try {
			workbook = new HSSFWorkbook(new FileInputStream(outPutFilePath));
			HSSFSheet sheet = workbook.getSheet("ViewInfo");
			HSSFRow datarow = sheet.getRow(row);
			HSSFCell cell = datarow.getCell(column);
			HSSFRichTextString text = new HSSFRichTextString("true");
			cell.setCellValue(text);

			FileOutputStream fileOut = null;
			fileOut = new FileOutputStream(outPutFilePath);

			workbook.write(fileOut);
			fileOut.close();
			workbook.close();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		
		
	}
	
	public void xmltoexcel(String filePath, String outPutFilePath){
		Element element = getRootElement(filePath);
		getNodes(element);
		toExcel(setViewInfo(elementList), outPutFilePath);
	}
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		XmlToExcel toExcel = new XmlToExcel();
		String filePath = "/data/local/tmp/";
		String InputfileName = "dump.xml";
		try {
			Runtime.getRuntime().exec(
					"adb shell uiautomator dump --compressed /data/local/tmp/" + InputfileName);
			Thread.sleep(1000);
		} catch (IOException | InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String outPutFilePath = "D://ViewInfo.xls";
		toExcel.xmltoexcel(filePath + InputfileName, outPutFilePath);
	}

}
