package viewtraversal;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import org.dom4j.Attribute;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

public class ParseXml {

	public List<ViewTreeNode> nodeList = new ArrayList<ViewTreeNode>();	
	int treeWeight = 0;
	
	public int getTreeWeight(ViewTreeNode node) {
		getWeightOfView(node);
		return treeWeight;
	}


	// ������document
	private Element getRootElement(String filePath) {
		SAXReader saxread = new SAXReader();
		Document document = null;

		InputStream inputStream;
		try {
			File xmlFile = new File(filePath);
			inputStream = new FileInputStream(xmlFile);
			document = saxread.read(inputStream);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (DocumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		Element elem = document.getRootElement();
		List<Element> listElement = elem.elements();
		Element rootElement = listElement.get(0);

		return rootElement;
	}
		
		
	private void getNodes(Element elem) {
		@SuppressWarnings("unchecked")
		List<Attribute> listAttr = elem.attributes();
		ViewTreeNode node = new ViewTreeNode();
		Element setParent = elem.getParent();
		if(!setParent.attribute(0).getName().equals("rotation")){
			String lastname = setParent.attribute("class").getValue();
			String tag = setParent.attribute("bounds").getValue() + lastname;
		node.setParentNodeTag(tag);
		}
		for (Attribute attr : listAttr) {
			String name = attr.getName();
			String value = attr.getValue();
			if (name == "clickable" || name == "resource-id"
					|| name == "class" || name == "checkable"
					|| name == "bounds" || name == "long-clickable"
					|| name == "text" || name == "scrollable")
				switch (name) {
				case "clickable":
					node.setClickable(value);
					break;
				case "resource-id":
					node.setResourceId(value);
					break;
				case "bounds":
					node.setBounds(value);
					break;
				case "long-clickable":
					node.setLongclickable(value);
					break;
				case "text":
					node.setText(value);
					break;
				case "scrollable":
					node.setScrollable(value);
					break;
				case "class":
					node.setClassname(value);
					break;
				case "checkable":
					node.setCheckable(value);
					break;
				default:
					break;
				}
			else {
				continue;
			}
		}
		String tag = node.getBounds() + node.getClassname();
		node.setTag(tag);
		nodeList.add(node);
		List<Element> listElement = elem.elements();
		for (Element e : listElement) {
			this.getNodes(e);
		}
	}

	private void setChildAndParentNode() {
		for (ViewTreeNode node : nodeList) {
			for (ViewTreeNode childNode : nodeList) {
				if(!(childNode.getParentNodeTag() == null)){
					boolean ischild = childNode.getParentNodeTag().equals(
							node.getTag());
					if (ischild) {
						node.setChildrenNode(childNode);
						childNode.setParentNode(node);
						childNode.setWeight(node.getWeight() +1);
					}
				}
				
				
			}
		}
	}
		

		
	public ViewTreeNode parseXml(String filePath){
		Element rootElement = getRootElement(filePath);
		getNodes(rootElement);
		setChildAndParentNode();
		ViewTreeNode node = nodeList.get(0);
		return node;
	}


	public void getWeightOfView(ViewTreeNode node){
		treeWeight = treeWeight + node.getWeight() ;
		for(ViewTreeNode chilNode:node.getChildrenNode())
			 getWeightOfView(chilNode);
	}
	
	

	
	public void print(ViewTreeNode node){
		System.out.println(node.getBounds());
		System.out.println(node.getClassname());
		System.out.println(node.getCheckable());
		System.out.println(node.getClicked());
		System.out.println(node.getLongclickable());
		System.out.println(node.getParentNodeTag());
		System.out.println(node.getResourceId());
		System.out.println(node.getScrollable());
		System.out.println(node.getTag());
		System.out.println(node.getText());
		System.out.println(node.getWeight());
		System.out.println(node.getChildrenNode().isEmpty());
		System.out.println("---------------------------------------");
		for(ViewTreeNode chilNode:node.getChildrenNode())
			print(chilNode);
	}
		
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ParseXml parsexml = new ParseXml();
		String filePath = "C:\\Users\\yeyanling\\Desktop\\Compress\\";
//		String filePath = "D:\\workspace\\soot-infoflow-android-develop\\data\\";
		String fileName = "dump1.xml";
//		String fileName = "MainActivity.xml";
		ViewTreeNode node = parsexml.parseXml(filePath + fileName);
		
		parsexml.print(node);
		
		System.out.println(parsexml.getTreeWeight(node));
		
	}

}
