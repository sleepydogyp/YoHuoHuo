package viewtraversal;

import java.io.BufferedWriter;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Stack;
import java.util.Map.Entry;

import org.xmlpull.v1.XmlPullParserException;

import soot.jimple.infoflow.android.SetupApplication;
import soot.jimple.infoflow.android.AndroidSourceSinkManager.LayoutMatchingMode;
import soot.jimple.infoflow.android.data.AndroidMethod;
import soot.jimple.infoflow.data.pathBuilders.DefaultPathBuilderFactory.PathBuilder;
import soot.jimple.infoflow.handlers.ResultsAvailableHandler;
import soot.jimple.infoflow.ipc.IIPCManager;
import soot.jimple.infoflow.results.InfoflowResults;
import soot.jimple.infoflow.results.ResultSinkInfo;
import soot.jimple.infoflow.results.ResultSourceInfo;
import soot.jimple.infoflow.solver.IInfoflowCFG;
import soot.jimple.infoflow.taintWrappers.EasyTaintWrapper;
import soot.jimple.infoflow.taintWrappers.ITaintPropagationWrapper;
import soot.jimple.infoflow.taintWrappers.TaintWrapperSet;

public class PathAnalysis {

	private static final class MyResultsAvailableHandler implements
			ResultsAvailableHandler {
		private final BufferedWriter wr;

		private MyResultsAvailableHandler() {
			this.wr = null;
		}

		private MyResultsAvailableHandler(BufferedWriter wr) {
			this.wr = wr;
		}

		@Override
		public void onResultsAvailable(IInfoflowCFG cfg, InfoflowResults results) {
			// Dump the results
			if (results == null) {
				print("No results found.");
			} else {
				for (ResultSinkInfo sink : results.getResults().keySet()) {
					print("Found a flow to sink " + sink
							+ ", from the following sources:");
					for (ResultSourceInfo source : results.getResults().get(
							sink)) {
						print("\t- "
								+ source.getSource()
								+ " (in "
								+ cfg.getMethodOf(source.getSource())
										.getSignature() + ")");
						if (source.getPath() != null
								&& !source.getPath().isEmpty())
							print("\t\ton Path " + source.getPath());
					}
				}
			}
		}

		private void print(String string) {
			try {
				System.out.println(string);
				if (wr != null)
					wr.write(string + "\n");
			} catch (IOException ex) {
				// ignore
			}
		}
	}
	
	static String command;
	static boolean generate = false;
	
	private static boolean stopAfterFirstFlow = false;
	private static boolean implicitFlows = false;
	private static boolean staticTracking = true;
	private static boolean enableCallbacks = true;
	private static boolean enableExceptions = true;
	private static int accessPathLength = 5;
	private static LayoutMatchingMode layoutMatchingMode = LayoutMatchingMode.MatchSensitiveOnly;
	private static boolean flowSensitiveAliasing = true;
	private static boolean computeResultPaths = true;
	private static boolean aggressiveTaintWrapper = false;
	private static boolean librarySummaryTaintWrapper = false;
	private static String summaryPath = "";
	private static PathBuilder pathBuilder = PathBuilder.ContextInsensitiveSourceFinder;
	
	private static boolean DEBUG = false;

	private static IIPCManager ipcManager = null;
	public static void setIPCManager(IIPCManager ipcManager)
	{
		PathAnalysis.ipcManager = ipcManager;
	}
	public static IIPCManager getIPCManager()
	{
		return PathAnalysis.ipcManager;
	}
	
	private static ITaintPropagationWrapper createLibrarySummaryTW()
			throws IOException {
		try {
			Class clzLazySummary = Class.forName("soot.jimple.infoflow.methodSummary.data.impl.LazySummary");
			
			Object lazySummary = clzLazySummary.getConstructor(File.class).newInstance(new File(summaryPath));
			
			ITaintPropagationWrapper summaryWrapper = (ITaintPropagationWrapper) Class.forName
					("soot.jimple.infoflow.methodSummary.taintWrappers.SummaryTaintWrapper").getConstructor
					(clzLazySummary).newInstance(lazySummary);
			
			final TaintWrapperSet taintWrapperSet = new TaintWrapperSet();
			taintWrapperSet.addWrapper(summaryWrapper);
			taintWrapperSet.addWrapper(new EasyTaintWrapper("EasyTaintWrapperConversion.txt"));
			return taintWrapperSet;
		}
		catch (Exception ex) {
			System.err.println("Could not find library summary classes: " + ex.getMessage());
			ex.printStackTrace();
			return null;
		}

	}
	
	public SensitivePoint myMethod(final String fileName, final String androidJar){
		try {
			final long beforeRun = System.nanoTime();

			final SetupApplication app;
			if (null == ipcManager)
			{
				app = new SetupApplication(androidJar, fileName);
			}
			else
			{
				app = new SetupApplication(androidJar, fileName, ipcManager);
			}

			app.setStopAfterFirstFlow(stopAfterFirstFlow);
			app.setEnableImplicitFlows(implicitFlows);
			app.setEnableStaticFieldTracking(staticTracking);
			app.setEnableCallbacks(enableCallbacks);
			app.setEnableExceptionTracking(enableExceptions);
			app.setAccessPathLength(accessPathLength);
			app.setLayoutMatchingMode(layoutMatchingMode);
			app.setFlowSensitiveAliasing(flowSensitiveAliasing);
			app.setPathBuilder(pathBuilder);
			app.setComputeResultPaths(computeResultPaths);
			
			final ITaintPropagationWrapper taintWrapper;
			if (librarySummaryTaintWrapper) {
				taintWrapper = createLibrarySummaryTW();
			}
			else {
				final EasyTaintWrapper easyTaintWrapper;
				if (new File("D:/workspace/soot-infoflow-android-develop/EasyTaintWrapperSource.txt").exists())
					easyTaintWrapper = new EasyTaintWrapper("D:/workspace/soot-infoflow-android-develop/EasyTaintWrapperSource.txt");
				else
					easyTaintWrapper = new EasyTaintWrapper("D:/workspace/soot-infoflow-android-develop/EasyTaintWrapperSource.txt");
				easyTaintWrapper.setAggressiveMode(aggressiveTaintWrapper);
				taintWrapper = easyTaintWrapper;
			}
			app.setTaintWrapper(taintWrapper);
			app.calculateSourcesSinksEntrypoints("SourcesAndSinks.txt");
			
			if (DEBUG) {
				app.printEntrypoints();
				app.printSinks();
				app.printSources();
			}
			System.out.println("Running data flow analysis...");
			
			app.runInfoFlow(new MyResultsAvailableHandler());
			
			SensitivePoint sensitivePath = new SensitivePoint();
			//onClick ---> startActivity
			sensitivePath.setStartActivityPoint(app.getStartActivityPoint());
//			sensitivePath.printStartActivityPoint();
			
			
			//Activity ---> CallbackMethods
			Map<String,Set<String>> callbacks = new HashMap<String, Set<String>>();
			Map<String, Set<AndroidMethod>> callbackMethods = app.getCallbackMethods();
			
			for(Entry<String, Set<AndroidMethod>> point: callbackMethods.entrySet()){
				String key = point.getKey();
				Set<AndroidMethod> methods = point.getValue();
				Iterator<AndroidMethod> itr = methods.iterator();
				Set<String> values = new HashSet<String>();
				while(itr.hasNext()){
					String value = itr.next().toString();
					values.add(value);
					System.out.println(key + " ======�� " + value);
				}
				callbacks.put(key, values);
				System.out.println();
			}
			sensitivePath.setCallbackMethods(callbacks);
			
			//callbackMethods--->sensitiveMethod
			sensitivePath.setMethodsToSensi(app.getMethodsToSensi());
			
			
			System.out.println("Analysis has run for " + (System.nanoTime() - beforeRun) / 1E9 + " seconds");
			return sensitivePath;
		} catch (IOException ex) {
			System.err.println("Could not read file: " + ex.getMessage());
			ex.printStackTrace();
			throw new RuntimeException(ex);
		} catch (XmlPullParserException ex) {
			System.err.println("Could not read Android manifest file: " + ex.getMessage());
			ex.printStackTrace();
			throw new RuntimeException(ex);
		}
		
	}
	public void calculateTable(List<Stack<String>> methodsToSensi,
			Map<String, String> startActivityPoint,
			Map<String, Set<String>> callbackMethods) {
		Set<String> activities = callbackMethods.keySet();
		for (String activity : activities) {
			for(String callback: callbackMethods.get(activity)){
				for(String key: startActivityPoint.keySet()){
					if(key.equals(callback)){
						SensitivePoint point = new SensitivePoint();
						point.setHaveNextLevel(true);
						
					}
				}
			}
		}
	}
	
	
}
