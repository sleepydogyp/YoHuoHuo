package viewtraversal;

import heros.solver.CountingThreadPoolExecutor;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.xmlpull.v1.XmlPullParserException;

import soot.PackManager;
import soot.Scene;
import soot.SootMethod;
import soot.Transform;
import soot.jimple.infoflow.Infoflow;
import soot.jimple.infoflow.IInfoflow.CallgraphAlgorithm;
import soot.jimple.infoflow.aliasing.FlowSensitiveAliasStrategy;
import soot.jimple.infoflow.aliasing.IAliasingStrategy;
import soot.jimple.infoflow.aliasing.PtsBasedAliasStrategy;
import soot.jimple.infoflow.android.AndroidSourceSinkManager;
import soot.jimple.infoflow.android.SetupApplication;
import soot.jimple.infoflow.android.SootConfigForAndroid;
import soot.jimple.infoflow.android.AndroidSourceSinkManager.LayoutMatchingMode;
import soot.jimple.infoflow.android.data.AndroidMethod;
import soot.jimple.infoflow.config.IInfoflowConfig;
import soot.jimple.infoflow.data.pathBuilders.DefaultPathBuilderFactory;
import soot.jimple.infoflow.data.pathBuilders.DefaultPathBuilderFactory.PathBuilder;
import soot.jimple.infoflow.entryPointCreators.AndroidEntryPointCreator;
import soot.jimple.infoflow.handlers.TaintPropagationHandler;
import soot.jimple.infoflow.ipc.IIPCManager;
import soot.jimple.infoflow.problems.BackwardsInfoflowProblem;
import soot.jimple.infoflow.problems.InfoflowProblem;
import soot.jimple.infoflow.solver.BackwardsInfoflowCFG;
import soot.jimple.infoflow.solver.fastSolver.InfoflowSolver;
import soot.jimple.infoflow.taintWrappers.EasyTaintWrapper;
import soot.jimple.infoflow.taintWrappers.ITaintPropagationWrapper;
import soot.jimple.infoflow.util.SootMethodRepresentationParser;
import soot.jimple.infoflow.yhz.ActivityAXmlNode;
import soot.jimple.infoflow.yhz.FourComponent;
import soot.jimple.infoflow.yhz.UIInfo;
import soot.jimple.infoflow.yhz.UITriggerInfo;
import soot.jimple.infoflow.yhz.UIXMLTriggerInfo;

public class CallAnalysis {

	String apkFileLocation = "D:/workspace/soot-infoflow-android-develop/testAPKs/ComponentAttr.apk";
	String androidJar = "D:/java_lib/android-platforms-master";
	private Map<String, List<String>> methods = new HashMap<String, List<String>>(10000);
	private AndroidSourceSinkManager sourceSinkManager = null;
	private AndroidEntryPointCreator entryPointCreator = null;
	private String appPackageName = "";
	private Set<AndroidMethod> sensitiveAPI = null;
	
	private static boolean implicitFlows = false;
	private static boolean staticTracking = true;
	private static int accessPathLength = 5;
	private static LayoutMatchingMode layoutMatchingMode = LayoutMatchingMode.MatchSensitiveOnly;
	private static boolean aggressiveTaintWrapper = false;
	private static boolean librarySummaryTaintWrapper = false;
	private static PathBuilder pathBuilder = PathBuilder.ContextInsensitiveSourceFinder;
	
	private IInfoflowConfig sootConfig = null;
	private boolean stopAfterFirstFlow = false;
	private boolean enableImplicitFlows = false;
	private boolean enableStaticFields = true;
	private boolean enableExceptions = true;
	private boolean enableCallbacks = true;
	private boolean flowSensitiveAliasing = true;
	private boolean ignoreFlowsInSystemPackages = true;
	private boolean enableCallbackSources = true;
	private boolean computeResultPaths = true;
	
	private CallgraphAlgorithm callgraphAlgorithm = CallgraphAlgorithm.AutomaticSelection;
	private IIPCManager ipcManager = null;
	private String mainActivityName="";
	private Map<String, UITriggerInfo> uIToCallBackMethod=new HashMap<String, UITriggerInfo>();
	private Map<Integer, String> viewIDToNameMap=new HashMap<Integer, String>();
	private Map<String, UIXMLTriggerInfo> layoutXmlUIToCallBackMethod=new HashMap<String, UIXMLTriggerInfo>();
	private FourComponent fourComponent=null;
	List<ActivityAXmlNode> activityAXmlNodeList=new ArrayList<ActivityAXmlNode>();
	
	//��resources.arsc�ļ���ȡ�����ַ�����ԴID���ַ����Ķ�Ӧ��ϵ
	private Map<Integer, String> resourceIDToString = new HashMap<Integer, String>();
	//�Ӳ���XML�ļ���ȡ���Ŀؼ�ID����ʾ�ַ����Ķ�Ӧ��ϵ
	private Map<Integer, UIInfo> viewIDToUIInfo = new HashMap<Integer, UIInfo>();
	
	
	public void callBackAndActivity(String apkFileLocation, String androidJar) throws IOException, XmlPullParserException{
		
		
		/*SetupApplication app;
		final ITaintPropagationWrapper taintWrapper = null;
		app = new SetupApplication(androidJar, apkFileLocation);
		
		app.setStopAfterFirstFlow(stopAfterFirstFlow);
		app.setEnableImplicitFlows(implicitFlows);
		app.setEnableStaticFieldTracking(staticTracking);
		app.setEnableCallbacks(enableCallbacks);
		app.setEnableExceptionTracking(enableExceptions);
		app.setAccessPathLength(accessPathLength);
		app.setLayoutMatchingMode(layoutMatchingMode);
		app.setFlowSensitiveAliasing(flowSensitiveAliasing);
		app.setPathBuilder(pathBuilder);
		app.setComputeResultPaths(computeResultPaths);
		
		final EasyTaintWrapper easyTaintWrapper;
		if (new File("D:/workspace/soot-infoflow-android-develop/EasyTaintWrapperSource.txt").exists())
			easyTaintWrapper = new EasyTaintWrapper("D:/workspace/soot-infoflow-android-develop/EasyTaintWrapperSource.txt");
		else
			easyTaintWrapper = new EasyTaintWrapper("D:/workspace/soot-infoflow-android-develop/EasyTaintWrapperSource.txt");
		easyTaintWrapper.setAggressiveMode(aggressiveTaintWrapper);
		
		
		app.setTaintWrapper(taintWrapper);
		app.calculateSourcesSinksEntrypoints("SourcesAndSinks.txt");
		sensitiveAPI = app.getSensitiveAPI();
		sourceSinkManager = app.getSourceSinkManager();
		entryPointCreator = app.getEntryPointCreator();
		methods = entryPointCreator.getCallbackFunctions();
		
		
		Infoflow info = new Infoflow(androidJar, false, null,
				new DefaultPathBuilderFactory(pathBuilder, computeResultPaths));
		String path = Scene.v().getAndroidJarPath(androidJar, apkFileLocation);
		info.setTaintWrapper(taintWrapper);
		info.setSootConfig(new SootConfigForAndroid());
		if (onResultsAvailable != null)
			info.addResultsAvailableHandler(onResultsAvailable);
						
		System.out.println("Starting infoflow computation...");
		info.setSootConfig(sootConfig);
		
		info.setStopAfterFirstFlow(stopAfterFirstFlow);
	
		info.setEnableImplicitFlows(enableImplicitFlows);
		info.setEnableStaticFieldTracking(enableStaticFields);
		info.setEnableExceptionTracking(enableExceptions);
		Infoflow.setAccessPathLength(accessPathLength);
		info.setFlowSensitiveAliasing(flowSensitiveAliasing);
		info.setIgnoreFlowsInSystemPackages(ignoreFlowsInSystemPackages);
		
		info.setInspectSources(false);
		info.setInspectSinks(false);
		
		info.setCallgraphAlgorithm(callgraphAlgorithm);
		
		if (null != ipcManager) {
			info.setIPCManager(ipcManager);
		}
		
		info.setMainActivityName(mainActivityName);
		info.setAppPackageName(appPackageName);
		info.setuIToCallBackMethod(uIToCallBackMethod);
		info.setViewIDToNameMap(viewIDToNameMap);
		info.setLayoutXmlUIToCallBackMethod(layoutXmlUIToCallBackMethod);
		info.setResourceIDToString(resourceIDToString);
		info.setViewIDToUIInfo(viewIDToUIInfo);
		info.setFourComponent(fourComponent);
		info.setActivityAXmlNodeList(activityAXmlNodeList);
		
		
		Set<String> apis=new HashSet<String>();
		for (AndroidMethod androidMethod : sensitiveAPI)
		{	
			apis.add(androidMethod.getMethodName());
		}
		info.setSensitiveAPI(apis);
		
		info.computeInfoFlow(apkFileLocation, androidJar, entryPointCreator, sourceSinkManager);*/
	}
	
	public void callGraph(){}
	
	
	
}
