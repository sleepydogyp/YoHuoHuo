package viewtraversal;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import jxl.Cell;
import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;

public class DataLoader {

	public class Data {
		public List<String> uiId = new ArrayList<String>();
		public List<String> uiText = new ArrayList<String>();
		public List<String> clickable = new ArrayList<String>();
		public List<String> scrollable = new ArrayList<String>();
		public List<String> longclickable = new ArrayList<String>();
		public List<String> bounds = new ArrayList<String>();
		public List<String> clicked = new ArrayList<String>();
	}

	public Data getData(InputStream is) {
		Workbook workbook;
		Data data=new Data();
		try {
			workbook = Workbook.getWorkbook(is);
			Sheet sheet = workbook.getSheet(0);
			Cell[] uiIdCell = sheet.getColumn(0);
			Cell[] uiTextCell = sheet.getColumn(1);
			Cell[] clickableCell = sheet.getColumn(2);
			Cell[] scrollableCell = sheet.getColumn(3);
			Cell[] longclickableCell = sheet.getColumn(4);;
			Cell[] boundsCell =sheet.getColumn(5);
			Cell[] clickedCell =sheet.getColumn(6);
			for (int i = 1; i < uiIdCell.length; i++) {
				data.uiId.add(uiIdCell[i].getContents());
				data.uiText.add(uiTextCell[i].getContents());
				data.clickable.add(clickableCell[i].getContents());
				data.scrollable.add(scrollableCell[i].getContents());
				data.longclickable.add(longclickableCell[i].getContents());
				data.bounds.add(boundsCell[i].getContents());
				data.clicked.add(clickedCell[i].getContents());
			}
		} catch (BiffException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return data;
	}
	

	
}
