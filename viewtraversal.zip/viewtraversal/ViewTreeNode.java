package viewtraversal;

import java.util.ArrayList;
import java.util.List;

public class ViewTreeNode {

	public ViewTreeNode parentNode = null;
	public String parentNodeTag = "null";
	public List<ViewTreeNode> childrenNode = new ArrayList<ViewTreeNode>();
	public String text = null;
	public String resourceId = null;
	public String classname = null;   //View Type
	public String checkable = null;
	public String clickable = null;
	public String scrollable = null;
	public String longclickable = null;
	public String bounds = null;
	public String clicked = "false";
	public int weight = 0;
	public String tag = null;

	
	
	
	
	public ViewTreeNode getParentNode() {
		return parentNode;
	}
	public void setParentNode(ViewTreeNode parentNode) {
		this.parentNode = parentNode;
	}

	public String getTag() {
		return tag;
	}
	public void setTag(String tag) {
		this.tag = tag;
	}
	public int getWeight() {
		return weight;
	}
	public void setWeight(int weight) {
		this.weight = weight;
	}
	public String getParentNodeTag() {
		return parentNodeTag;
	}
	public void setParentNodeTag(String parentNodeTag) {
		this.parentNodeTag = parentNodeTag;
	}
	
	public List<ViewTreeNode> getChildrenNode() {
		return childrenNode;
	}
	public void setChildrenNode(ViewTreeNode childrenNode) {
		this.childrenNode.add(childrenNode);
	}
	
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}
	public String getResourceId() {
		return resourceId;
	}
	public void setResourceId(String resourceId) {
		this.resourceId = resourceId;
	}
	public String getClassname() {
		return classname;
	}
	public void setClassname(String classname) {
		this.classname = classname;
	}
	public String getCheckable() {
		return checkable;
	}
	public void setCheckable(String checkable) {
		this.checkable = checkable;
	}
	public String getClickable() {
		return clickable;
	}
	public void setClickable(String clickable) {
		this.clickable = clickable;
	}
	public String getScrollable() {
		return scrollable;
	}
	public void setScrollable(String scrollable) {
		this.scrollable = scrollable;
	}
	public String getLongclickable() {
		return longclickable;
	}
	public void setLongclickable(String longclickable) {
		this.longclickable = longclickable;
	}
	public String getBounds() {
		return bounds;
	}
	public void setBounds(String bounds) {
		this.bounds = bounds;
	}
	public String getClicked() {
		return clicked;
	}
	public void setClicked(String clicked) {
		this.clicked = clicked;
	}
	
}
