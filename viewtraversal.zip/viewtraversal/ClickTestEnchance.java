package viewtraversal;

import java.awt.Point;
import java.awt.Rectangle;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Stack;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.xmlpull.v1.XmlPullParserException;

import soot.jimple.infoflow.android.axml.AXmlNode;
import soot.jimple.infoflow.android.manifest.ProcessManifest;


public class ClickTestEnchance {

	String filePath = "D:\\workspace\\soot-infoflow-android-develop\\data";
//	String pkgName;
	InputStream is;
	int i = 0;
	public String packageName = null;
	public String mainActivityName = null;
	Stack<String> acStack = new Stack<String>();
	private ArrayList<AXmlNode> activityList = new ArrayList<AXmlNode>();
	
	ViewTreeNode rootNode = new ViewTreeNode();
	public List<HashMap<String, String>> clickedList = new ArrayList<HashMap<String,String>>();
	
	String stackTopAc = null;
//	String currentAc = null;
//	static ArrayList<String> viewList = new ArrayList<String>();  
	
	public ClickTestEnchance(String apkFileLocation){

//		installApp(apkFileLocation);
		ProcessManifest processMan;
		try {
			processMan = new ProcessManifest(apkFileLocation);
			packageName = processMan.getPackageName();
			String mainAcName=processMan.getMainActivityName();
			mainActivityName = mainAcName.substring(mainAcName.lastIndexOf("."), mainAcName.length());
			activityList = processMan.getActivities();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (XmlPullParserException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	
	public void installApp(String apkFileLocation){
		try {
			Runtime.getRuntime().exec("adb install " + apkFileLocation);
			Thread.sleep(1000);
		} catch (IOException | InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("APP installed!");
	}
	
	public void openApp() {
	
		try {
			Runtime.getRuntime().exec(
					"adb shell am start -n " + packageName + "/" + mainActivityName);
			Thread.sleep(1000);
			System.out.println("App�Ѵ�");// ////////////////
		} catch (IOException | InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
	}
	
	private void backToPrevious() throws IOException, InterruptedException {
		Runtime.getRuntime().exec("adb shell input keyevent KEYCODE_BACK");
		Thread.sleep(1000);
			System.out.println("�����豸����back����!");
		Thread.sleep(100);
	}

	

	public void click(Point point) throws IOException, InterruptedException {
		Process process = Runtime.getRuntime().exec(
				"adb shell input tap " + point.x + " " + point.y);
		InputStream stderr = process.getInputStream();
		InputStreamReader isr = new InputStreamReader(stderr);
		BufferedReader br = new BufferedReader(isr);
		String line = null;
		while ((line = br.readLine()) != null)
			System.out.println(line);
		int exitCode = process.waitFor();
		if (exitCode == 0)
			System.out.println("�����豸����click����!");
		Thread.sleep(100);
	}
	
	public Point getCentralPoint(String s) {
		Rectangle rect;
		Point point1 = new Point();
		Point point2 = new Point();
		StringBuilder sb = new StringBuilder();
		int width;
		int hight;

		Pattern patten1 = Pattern.compile("\\[(.+?)\\]");
		Pattern patten2 = Pattern.compile("[,]");

		Matcher matcher = patten1.matcher(s);

		while (matcher.find() && matcher.group() != ""
				&& matcher.group() != null) {
			sb.append(matcher.group(1));
			sb.append(",");
		}
		String[] coordi = patten2.split(sb);

		point1.x = Integer.decode(coordi[0]);
		point1.y = Integer.decode(coordi[1]);
		point2.x = Integer.decode(coordi[2]);
		point2.y = Integer.decode(coordi[3]);
		width = point2.x - point1.x;
		hight = point2.y - point1.y;
		rect = new Rectangle(point1);
		rect.width = width;
		rect.height = hight;
		Point point = new Point();
		point.x = (int) rect.getCenterX();
		point.y = (int) rect.getCenterY();
		return point;
	}
	

	//��ǰView����Ϣ
	public void currentViewInfo(String xmlFileName, String filePath){
		
		try {
			Runtime.getRuntime().exec(
					"adb shell uiautomator dump --compressed /data/local/tmp/" + xmlFileName);
			Thread.sleep(2000);
			Runtime.getRuntime().exec("adb pull /data/local/tmp/" + xmlFileName + " " + filePath);
			Thread.sleep(1000);
			Runtime.getRuntime().exec("adb shell rm -r /data/local/tmp/" + xmlFileName);
			Thread.sleep(100);
			System.out.println("--------------");
		} catch (IOException | InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	}
	
	public ViewTreeNode parseXml(String xmlFileName, String filePath){
		ParseXml parsexml = new ParseXml();
		ViewTreeNode node = parsexml.parseXml(filePath + "\\" + xmlFileName);
		int weight = parsexml.getTreeWeight(node);
		node.setWeight(weight);
		
		System.out.println("NodeTag is :" + node.getTag());
		System.out.println("weight is : " + weight);
		return node;
	}
	
	
	//��ȡ��ǰActivity��Ϣ
	public String getCurrentActivity(){
		String currentAc = null;
		String acInfo = null;
		try {
			Process process = Runtime.getRuntime().exec("adb shell dumpsys activity top | grep ACTIVITY");
			BufferedReader strCon = new BufferedReader(new InputStreamReader(process.getInputStream()));
			acInfo = strCon.readLine();
//			System.out.println(acInfo);
//			acInfo = acInfo.trim();
			String[] acInfos = acInfo.split(" ");
			currentAc = acInfos[3];
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("currentAc is : " + currentAc);
		return currentAc;
	}
	
	//ջ��Activity
	public String stackTopAc(){
		stackTopAc = acStack.peek();
		
		
		/*try {
			Process process = Runtime.getRuntime().exec("adb shell dumpsys activity -p " + packageName + " a");
			BufferedReader strCon = new BufferedReader(new InputStreamReader(process.getInputStream()));
			while((stackTopAc = strCon.readLine()) != null){
				
//				System.out.println(stackTopAc);

				stackTopAc = stackTopAc.trim();
				if (stackTopAc.startsWith("Run #")) {
					String[] acInfos = stackTopAc.split(" ");
					stackTopAc = acInfos[4];
					break;
				}
				else
					continue;
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		System.out.println("stackTopAc is : " + stackTopAc);
		return stackTopAc;
	}
	
	public boolean activitySkip(){
		boolean acSkip = true;
		String currentAc = getCurrentActivity();
		if (stackTopAc.equals(currentAc))
			acSkip = false;
		System.out.println(acSkip);
		return acSkip;
	}

	
	public void clickForward(ViewTreeNode view){

		boolean skip = true;
		
		if (view.getClickable().equals("true") || view.getCheckable().equals("true")) {
			if(view.getClassname().equals("android.widget.EditText")){
				HashMap<String, String> clicked = new HashMap<String, String>();
				clicked.put(view.getParentNodeTag(), view.getTag());
				clickedList.add(clicked);
				setParentClicked(view);
				getNextUncliked(view);
			}else{
			String bound = " ";
			bound = view.getBounds();
			System.out.println(bound);
			String topAc = acStack.peek();
			HashMap<String, String> clicked = new HashMap<String, String>();
			clicked.put(topAc + view.getParentNodeTag(), topAc + view.getTag());
			clickedList.add(clicked);
			setParentClicked(view);
			try {
				click(getCentralPoint(bound));
				// Thread.sleep(100);
			} catch (IOException | InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			

			view.setClicked("true");
			stackTopAc();
			skip = activitySkip();
			if (skip) {
			
				ViewTreeNode newView = ifSkip();
				clickInActivity(newView);
			} else {
				notSkip(view);
			}
			}

		} else {
			
			if (view.getChildrenNode().isEmpty() ) {
				getCurrentActivity();
				HashMap<String, String> clicked = new HashMap<String, String>();
				clicked.put(acStack.peek() + view.getParentNodeTag(), acStack.peek() + view.getTag());
				clickedList.add(clicked);
				setParentClicked(view);
				getNextUncliked(view);
			} else {

				ViewTreeNode node = view.getChildrenNode().get(0);
				clickInActivity(node);
				/*for (ViewTreeNode node : view.getChildrenNode()) {
					clickInActivity(node);
				}*/
			}
		}
	}
	
	
    //��������ж�Activity�Ƿ���ת
	public void clickInActivity(ViewTreeNode view) {
		if (clickedList.isEmpty()) {
			clickForward(view);
		} else {
			boolean isclicked = isclicked(view);
			
			if (isclicked) {
				getNextUncliked(view);
			} else {
				clickForward(view);
			}
		}

	}

	public ViewTreeNode ifSkip(){

//		String filePath = "D:\\workspace\\soot-infoflow-android-develop\\data";

		String currentAc = getCurrentActivity();
		acStack.add(currentAc);
		String fileName = fileName();
		String xmlFileName = fileName + ".xml";
		currentViewInfo(xmlFileName, filePath);
		ViewTreeNode view = parseXml(xmlFileName, filePath);
		return view;
	}
	
	public void notSkip(ViewTreeNode view) {
		i++;
		
		String newfileName = "dump" + i + ".xml";
		currentViewInfo(newfileName, filePath);
		ViewTreeNode newView = parseXml(newfileName, filePath);
		getRootNode(view);
		if (newView.getWeight() == rootNode.getWeight()) {
			if (view.getChildrenNode().isEmpty()) {
			
				getNextUncliked(view);
				
			} else {
				ViewTreeNode node = view.getChildrenNode().get(0);
				clickInActivity(node);
				/*for (ViewTreeNode node : view.getChildrenNode()) {
					clickInActivity(node);
				}*/
			}
		} else {
			// �ж� newView�Ƿ���clickedList��
			boolean isclicked = isclicked(newView);

			if (isclicked) {
				getNextUncliked(newView);
			} else {
				clickForward(newView);
			}
		}

	}

	
	public boolean isclicked(ViewTreeNode node){
		boolean isclicked = false;
		for (HashMap<String, String> clickednode : clickedList) {
			if (clickednode.containsValue(acStack.peek() + node.getTag())) {
				isclicked = true;
				break;
			} else {
				isclicked = false;
			}
		}
		return isclicked;
	}
	
	public void getRootNode(ViewTreeNode node){
		
		if(!node.getParentNodeTag().equals("null")){
			rootNode = node.getParentNode();
		getRootNode(rootNode);
		}
	}
	
    //�õ�ͬ��δ����ڵ�, ���ͬ���ڵ�ȫ������������ݵ���һ���ڵ�
	public void getNextUncliked(ViewTreeNode view){
		if (!view.getParentNodeTag().equals("null")) {
			ViewTreeNode parent = view.getParentNode();
			int index = parent.getChildrenNode().indexOf(view);
			if (index == (parent.getChildrenNode().size() - 1)) {
				getNextUncliked(parent);
			} else {
				ViewTreeNode node = parent.getChildrenNode().get(index + 1);
				clickInActivity(node);
				/*for (int j = index + 1; j < parent.getChildrenNode().size(); j++) {
					ViewTreeNode node = parent.getChildrenNode().get(j);
					clickInActivity(node);
				}*/
			}
		}
		else{
			getBack();
			
		}
	}
	
	public void getBack(){
		
		if (acStack.peek().equals(packageName + "/" + mainActivityName)) {
			System.exit(0);
		} else {
			try {
				backToPrevious();
			} catch (IOException | InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			acStack.pop();
			String xmlfileName = fileName() + ".xml";
			ViewTreeNode node = parseXml(xmlfileName, filePath);
			clickInActivity(node);
		}
	}

	public void setParentClicked(ViewTreeNode node){
		int i = 0;
		ViewTreeNode parent = node.getParentNode();
		String parentTag = node.getParentNodeTag();
		if (!parentTag.equals("null")) {
			for (HashMap<String, String> clicked : clickedList) {
				Iterator it = clicked.entrySet().iterator();
				while (it.hasNext()) {
					Map.Entry entry = (Map.Entry) it.next();
					if (entry.getKey().equals(acStack.peek() + parentTag))
						i++;
				}
			}

			if (!parentTag.equals("null") && i == parent.getChildrenNode().size()) {
				HashMap<String, String> clicked = new HashMap<String, String>();
				clicked.put(acStack.peek() + parent.getParentNodeTag(), acStack.peek() + parent.getTag());
				clickedList.add(clicked);
				setParentClicked(parent);
			}
		}
	
	}
	
	public String fileName(){
		String name = null;
		String currentAc = getCurrentActivity();
		int lastIndex= currentAc.lastIndexOf(".");
		name = currentAc.substring(lastIndex);
		name = name.substring(1);
		
		System.out.println("filename is : " + name);
		return name;
	}
	
	public DataLoader.Data setTestData(String filePath,String excelFileName){
		DataLoader.Data testData = null;
		try {
			is = new FileInputStream(filePath +"\\" + excelFileName);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		testData = new DataLoader().getData(is);
		return testData;
	}

	public ArrayList<AXmlNode> getActivityList() {
		return activityList;
	}

	public void setActivityList(ArrayList<AXmlNode> activityList) {
		this.activityList = activityList;
	}

	
}
