package viewtraversal;


public class MyTest {

	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	

		
//		String apkFileLocation = "D:/workspace/soot-infoflow-android-develop/testAPKs/Buttontest.apk";
		String apkFileLocation = "D:/workspace/soot-infoflow-android-develop/testAPKs/ComponentAttr.apk";
//		String apkFileLocation = "D:/workspace/soot-infoflow-android-develop/testAPKs/InsecureBank.apk";
//		String filePath = "D:\\workspace\\soot-infoflow-android-develop\\data";
		String androidJar = "D:/java_lib/android-platforms-master";
		
		
		PathAnalysis pathAnalysis = new PathAnalysis();
		SensitivePoint sensitivePath = pathAnalysis.myMethod(apkFileLocation, androidJar);
		sensitivePath.printStartActivityPoint();

		
		sensitivePath.setOtherActivities(apkFileLocation);
		
		sensitivePath.printMethodsToSensi();

	}
	
	

}
